package com.example.notas;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, body, toolbar;
    android.content.SharedPreferences prefs;
    JSONArray notes;
    boolean dark=false, hiddenMode=false;
    String openedId=null;
    static final int PICK_MEDIA=42;

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("notes",0); dark=prefs.getBoolean("dark",false); hiddenMode=prefs.getBoolean("hiddenMode",false); try{notes=new JSONArray(prefs.getString("data","[]"));}catch(Exception e){notes=new JSONArray();} showHome(); }
    int bg(){return dark?Color.rgb(24,24,27):Color.WHITE;} int fg(){return dark?Color.WHITE:Color.rgb(25,25,30);}
    void save(){prefs.edit().putString("data",notes.toString()).putBoolean("dark",dark).putBoolean("hiddenMode",hiddenMode).apply();}
    void setup(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(18,16,18,16);root.setBackgroundColor(bg());setContentView(root);
        TextView head=new TextView(this);head.setText(title);head.setTextSize(25);head.setTextColor(fg());head.setPadding(0,4,0,16);root.addView(head);
        ScrollView sc=new ScrollView(this); body=new LinearLayout(this);body.setOrientation(1);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); }
    TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(fg());t.setTextSize(size);t.setPadding(10,10,10,10);return t;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(fg());e.setHintTextColor(dark?0xffaaaaaa:0xff666666);return e;}
    JSONObject noteById(String id){for(int i=0;i<notes.length();i++){JSONObject n=notes.optJSONObject(i);if(n!=null&&id.equals(n.optString("id")))return n;}return null;}
    void showHome(){openedId=null;setup("Minhas anotações");
        body.addView(button("＋ Criar novo",()->createNote()));
        body.addView(button("⚙ Configurações",()->settings()));
        body.addView(button("🌐 Tradutor",()->translator()));
        body.addView(text("Blocos de anotações",18));
        for(int i=0;i<notes.length();i++){JSONObject n=notes.optJSONObject(i);if(n==null)continue;if(n.optBoolean("hidden",false)&&hiddenMode)continue;
            String id=n.optString("id");String label=n.optString("name","Sem nome")+(n.optBoolean("locked",false)?" 🔒":"")+(n.optBoolean("hidden",false)?" · Oculto":"");
            body.addView(button(label,()->openNote(id)));
            body.addView(button("Excluir “"+n.optString("name")+"”",()->new AlertDialog.Builder(this).setMessage("Excluir este bloco e seu conteúdo?").setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(d,w)->{removeNote(id);showHome();}).show()));
        }
        if(notes.length()==0)body.addView(text("Nenhum bloco ainda. Toque em “Criar novo”.",16));
    }
    void removeNote(String id){JSONArray a=new JSONArray();for(int i=0;i<notes.length();i++){JSONObject n=notes.optJSONObject(i);if(n!=null&&!id.equals(n.optString("id")))a.put(n);}notes=a;save();}
    void createNote(){LinearLayout form=new LinearLayout(this);form.setOrientation(1);EditText name=edit("Nome do bloco");form.addView(name);
        CheckBox lock=new CheckBox(this);lock.setText("Exigir senha de 8 dígitos");form.addView(lock);EditText pass=edit("Senha de 8 dígitos (opcional)");pass.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);pass.setVisibility(View.GONE);form.addView(pass);lock.setOnCheckedChangeListener((b,c)->pass.setVisibility(c?View.VISIBLE:View.GONE));
        CheckBox hide=new CheckBox(this);hide.setText("Manter oculto quando o modo oculto estiver ativo");form.addView(hide);
        new AlertDialog.Builder(this).setTitle("Novo bloco").setView(form).setNegativeButton("Cancelar",null).setPositiveButton("Criar",(d,w)->{
            String nm=name.getText().toString().trim(), pw=pass.getText().toString();
            if(nm.isEmpty()){toast("Digite um nome.");return;}if(lock.isChecked()&&!pw.matches("\\d{8}")){toast("A senha precisa ter exatamente 8 dígitos.");return;}
            JSONObject n=new JSONObject();try{n.put("id",UUID.randomUUID().toString());n.put("name",nm);n.put("locked",lock.isChecked());n.put("password",lock.isChecked()?pw:"");n.put("hidden",hide.isChecked());n.put("pages",new JSONArray().put(""));n.put("media",new JSONArray());notes.put(n);}catch(Exception e){}save();openNote(n.optString("id"));
        }).show();}
    void openNote(String id){JSONObject n=noteById(id);if(n==null)return;
        if(n.optBoolean("locked",false)){EditText p=edit("Senha de 8 dígitos");p.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("Bloco protegido").setView(p).setNegativeButton("Cancelar",(d,w)->showHome()).setPositiveButton("Abrir",(d,w)->{if(p.getText().toString().equals(n.optString("password")))editor(id,0);else toast("Senha incorreta.");}).show();}else editor(id,0);
    }
    void editor(String id,int page){JSONObject n=noteById(id);if(n==null)return;openedId=id;JSONArray rawPages=n.optJSONArray("pages");if(rawPages==null){rawPages=new JSONArray().put("");try{n.put("pages",rawPages);}catch(Exception e){}}
        if(page>=rawPages.length())page=rawPages.length()-1;if(page<0)page=0;final int pg=page;final JSONArray pages=rawPages;
        setup(n.optString("name")+" · Página "+(page+1)+"/"+pages.length());
        EditText content=edit("Escreva sua anotação aqui...");content.setGravity(Gravity.TOP|Gravity.START);content.setMinLines(12);content.setText(pages.optString(page,""));content.setTextSize(17);body.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        body.addView(button("Salvar",()->{try{pages.put(pg,content.getText().toString());n.put("pages",pages);save();toast("Anotação salva.");}catch(Exception e){toast("Não foi possível salvar.");}}));
        LinearLayout nav=new LinearLayout(this);nav.addView(button("← Anterior",()->{persistText(n,pages,pg,content);editor(id,pg-1);}),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button("Próxima →",()->{persistText(n,pages,pg,content);editor(id,pg+1);}),new LinearLayout.LayoutParams(0,-2,1));body.addView(nav);
        body.addView(button("＋ Nova página",()->{if(pages.length()>=100){toast("Limite de 100 páginas atingido.");return;}persistText(n,pages,pg,content);pages.put("");try{n.put("pages",pages);}catch(Exception e){}save();editor(id,pages.length()-1);}));
        body.addView(button("＋ Adicionar imagem/vídeo da galeria",()->{persistText(n,pages,pg,content);Intent it=new Intent(Intent.ACTION_OPEN_DOCUMENT);it.setType("*/*");it.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});it.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(it,PICK_MEDIA);}));
        JSONArray media=n.optJSONArray("media");if(media!=null)for(int i=0;i<media.length();i++){String u=media.optString(i);TextView mt=text("Anexo "+(i+1)+": "+u,12);body.addView(mt);final String uri=u;final int idx=i;body.addView(button("Abrir anexo "+(i+1),()->{try{Intent v=new Intent(Intent.ACTION_VIEW,Uri.parse(uri));v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(v);}catch(Exception e){toast("Não foi possível abrir o arquivo.");}}));}
        body.addView(button("Voltar ao início",()->{persistText(n,pages,pg,content);showHome();}));
    }
    void persistText(JSONObject n,JSONArray pages,int pg,EditText e){try{pages.put(pg,e.getText().toString());n.put("pages",pages);save();}catch(Exception ex){}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_MEDIA&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){JSONObject n=noteById(openedId);if(n!=null){Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception e){}JSONArray a=n.optJSONArray("media");if(a==null)a=new JSONArray();a.put(u.toString());try{n.put("media",a);}catch(Exception e){}save();editor(openedId,0);}}}
    void settings(){setup("Configurações");body.addView(button("Tema: "+(dark?"Preto":"Branco")+" (toque para alternar",()->{dark=!dark;save();settings();}));body.addView(text("Modo oculto",18));body.addView(text("Ao ativar, blocos marcados como ocultos somem da tela inicial. Para manter o comportamento de “erro desconhecido”, o modo só muda depois de informar o código no botão Reportar.",15));
        body.addView(button((hiddenMode?"Desativar":"Ativar")+" modo oculto",()->new AlertDialog.Builder(this).setTitle("Erro desconhecido").setMessage("Ocorreu um erro desconhecido. Deseja reportar?").setNegativeButton("Cancelar",(d,w)->settings()).setPositiveButton("Reportar",(d,w)->reportCode()).show()));
        body.addView(button("Voltar",()->showHome()));}
    void reportCode(){EditText code=edit("Código de reporte");new AlertDialog.Builder(this).setTitle("Reportar erro").setMessage("Digite o código para continuar.").setView(code).setNegativeButton("Cancelar",(d,w)->settings()).setPositiveButton("Enviar",(d,w)->{if("samukasntadaluz".equals(code.getText().toString())){hiddenMode=!hiddenMode;save();toast("Modo oculto "+(hiddenMode?"ativado":"desativado")+".");}else toast("Código inválido.");settings();}).show();}
    void translator(){setup("Tradutor");Spinner from=new Spinner(this),to=new Spinner(this);String[] langs={"Português","English","Español"};ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,langs);from.setAdapter(ad);to.setAdapter(ad);to.setSelection(1);EditText input=edit("Texto para traduzir");TextView result=text("A tradução aparecerá aqui.",17);body.addView(text("De:",14));body.addView(from);body.addView(text("Para:",14));body.addView(to);body.addView(input);body.addView(button("Traduzir",()->{String s=input.getText().toString().trim();if(s.isEmpty()){result.setText("Digite um texto.");return;}String f=langs[from.getSelectedItemPosition()],t=langs[to.getSelectedItemPosition()];if(f.equals(t)){result.setText(s);return;}result.setText("Para traduzir textos de verdade entre "+f+" e "+t+", é necessária uma conexão com um serviço de tradução. Esta versão não envia seus textos a nenhum serviço externo.");}));body.addView(result);body.addView(button("Voltar",()->showHome()));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
